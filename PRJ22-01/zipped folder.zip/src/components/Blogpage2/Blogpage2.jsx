import React from 'react'
import {Link} from 'react-router-dom';
import Blog10 from '../Img/Blog10.jpg'
import Blog11 from '../Img/Blog11.jpg'
import Blog12 from '../Img/Blog12.jpg'
import Blog13 from '../Img/Blog13.jpg'
import Blog14 from '../Img/Blog14.jpg'
import Blog15 from '../Img/Blog15.jpg'
import Blog16 from '../Img/Blog16.jpg'
import Blog17 from '../Img/Blog17.jpg'
import Blog18 from '../Img/Blog18.jpg'


export default function Blog() {
  return (
   <div>
     <h1 className="main-heading text-center">All Posts</h1>
     <section className="section border-top">
    <div className="container">
        <div className="row">
            <div className="col-md-12 mb-4text-center">
                 
                 <div className="underline mx-auto"></div>
            </div>


             <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog10} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/why-investment-decision-based-on-large-cap-and-small-cap-is-flawed/" rel="bookmark"><h4>5 Common Myths About<br/>Mutual Funds</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  February 1,2021 <i class="bi bi-chat"></i>  0</div>
                     </div>
                     </div>
                     </div>


                  <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                <img src={Blog11} className="w-100 border-bottom" alt="Blog"/>
                <div className="card-body">
                <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                 <div className="underline"></div>
                 <Link className="onClick" to="/guardian-capital-what-to-expect-from-your-investments-going-forward/" rel="bookmark"><h4>Stock Markets in Developed<br/>vs Developing Economies </h4></Link>
                 <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  January 14,2021 <i class="bi bi-chat"></i>  0</div>
                 </div>
                </div>
                </div>


                  <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog12} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/5-questions-to-ask-your-wealth-manager/" rel="bookmark"><h4>Work from home and work<br/>from office lessons we learned<br/>at Guardian this chaotic year</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  December 30,2020 <i class="bi bi-chat"></i>  0</div>
                        </div>
                     </div>
                     </div>


                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                 <img src={Blog13} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/should-one-run-after-returns-or-save-more-whats-important/" rel="bookmark"><h4>I invest all my<br/>earnings/savings in my busi-<br/>ness. Is it a good strategy?</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  December 15,2020 <i class="bi bi-chat"></i>  0</div>
                        </div>
                     </div>
                     </div>

                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog14} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>FINANCIAL CONSULTING, GUARDIAN, SMART<br/>INVESTING, TRADITIONAL INVESTMENTS</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/basic-insurances-for-every-individual/" rel="bookmark"><h4>When Does One Need<br/>Financial Planning?</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  December 5,2020 <i class="bi bi-chat"></i>  0</div>
                      </div>
                     </div>
                     </div>



                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog15} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>EQUITY INVESTMENTS, FINANCIAL<br/>CONSULTING, GUARDIAN, RESEARCH, SMART<br/>INVESTING, TRADITIONAL INVESTMENTS</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/small-cap-funds/" rel="bookmark"><h4>Pause! Reflect! Getting the<br/>best out of your spending.</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  November 17,2020 <i class="bi bi-chat"></i>  0</div>
                    </div>
                     </div>
                     </div>



                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog16} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>GUARDIAN</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/work-from-home-version-2-0-guess-whos-backback-again/" rel="bookmark"><h4>Work from Home, Version 2.0: Guess Who’s Back…Back<br/> Again…</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  May 3,2021 <i class="bi bi-chat"></i>  0</div>
                        </div>
                     </div>
                     </div>



                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog17} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/high-pe-valuations-how-does-it-affect-if-valuations-correct/" rel="bookmark"><h4>High PE – valuations? How<br/> does it affect if valuations<br/> correct?</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i>  March 1,2021 <i class="bi bi-chat"></i>  0</div>
                        </div>
                     </div>
                     </div>


                     <div className="col-md-4" style={{padding:'30px'}}>
                 <div>
                     <img src={Blog18} className="w-100 border-bottom" alt="Blog"/>
                     <div className="card-body">
                        <h6 style={{padding:'5px',color:'#8A8A8A'}}>UNCATEGORIZED</h6>
                        <div className="underline"></div>
                        <Link className="onClick" to="/union-budget-highlights-2021/" rel="bookmark"><h4>Union Budget Highlights –<br/> 2021</h4></Link>
                        <div style={{color:'#A9ADB1'}}><i class="bi bi-watch"></i> February 4,2021 <i class="bi bi-chat"></i>  0</div>
                        </div>
                     </div>
                     </div>
               <h2> The End of the World is Here, or is is? -A Market perspective</h2>
               <p>do we need to really panic about this sell off or traet is as an opportunity</p>
        </div>
    </div>
</section>
   </div>
  )
}
